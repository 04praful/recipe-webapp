import { createContext } from "react";

const recContext = createContext()


export default recContext