import { useState } from "react";
import recContext from "./recContext";


const ContextProvider = ({ children }) => {
    const [current, setCurrent] = useState({})


    return <recContext.Provider value={{ current, setCurrent }}>
        {children}
    </recContext.Provider>
}

export default ContextProvider