import React from 'react';

import { useContext } from 'react'
import recContext from '../context/recContext'
import { Link } from 'react-router-dom';
function RecipeDetails() {

    const { current } = useContext(recContext)

    console.log(current)
    return (
        <div className="container my-5">
            <div className="row">
                <div className="col-lg-6 offset-lg-3">
                    <div className="card">
                        <img src={current.image} className="card-img-top" alt={current.title} />
                        <div className="card-body">
                            <h5 className="card-title">{current.label}</h5>
                            <p className="card-text">{current.calories}</p>
                            <Link to="/" className="btn btn-primary">Back to Recipes</Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}

export default RecipeDetails;
