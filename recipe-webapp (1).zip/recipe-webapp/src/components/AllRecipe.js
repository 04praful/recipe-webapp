import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
import { useContext } from 'react'
import recContext from '../context/recContext'
const AllRecipe = () => {
    const [recipes, setRecipes] = useState([])
    const { setCurrent } = useContext(recContext)
    const fetchRecipeHandler = async () => {
        try {
            const response = await axios(`https://api.edamam.com/api/recipes/v2?q=chicken&type=public&app_id=d615a7f3&app_key=82c90f9be614916fdd682d79c7d480b9`)

            if (response.status == 200) {
                setRecipes(response.data.hits)
            }
        } catch (error) {
            console.log(error)
        }
    }
    console.log(recipes)
    useEffect(() => {
        fetchRecipeHandler()
    }, [])
    return (
        <div className="container my-5">
            <h1 className="text-center">Amazing Recipes</h1>
            <div className="row">
                {
                    recipes.map((rec) => {
                        return (
                            <div className="col-lg-4 col-md-6 mb-4">
                                <div className="card">
                                    <img src={rec.recipe.image} className="card-img-top" alt={'recipe img'} />
                                    <div className="card-body">
                                        <h5 className="card-title">{rec.recipe.label}</h5>
                                        <p className="card-text">{rec.recipe.calories}</p>
                                        <Link to='/obj' onClick={() => setCurrent(rec.recipe)} className="btn btn-primary">View Recipe</Link>

                                    </div>
                                </div>
                            </div>
                        )
                    })
                }
            </div>
        </div >
    )
}

export default AllRecipe