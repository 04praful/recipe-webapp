import React from 'react'
import AllRecipe from './components/AllRecipe'
import { Routes, Route, Router } from 'react-router-dom'
import RecipeDetails from './components/RecipeDetails'
import ContextProvider from './context/recContextProvider'
const App = () => {
  return (
    <div>
      <ContextProvider>


        <Routes>
          <Route path='/' element={<AllRecipe />} />
          <Route path='/:obj' element={<RecipeDetails />} />
        </Routes>
      </ContextProvider>
    </div>
  )
}

export default App